package analizadorDeResultados;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el nombre del equipo a consultar: ");
        String team = sc.nextLine();

        StatisticsService service = new StatisticsService("results.csv");

        Stats stats = service.getStatsForTeam(team);

        System.out.println("\n=== Estadísticas de " + team + " ===");
        System.out.println(stats);
    }
}

