/**
 * 
 */
/**
 * 
 */
module ProyectoFinalPOO {
	requires java.desktop;
}